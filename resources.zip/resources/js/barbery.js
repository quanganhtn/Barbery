// ===== DOM HELPERS (BẮT BUỘC) =====
window.$id = function (id) {
    return document.getElementById(id);
};

// ===== CATALOG (LOAD FROM API) =====
let services = [];
let stylists = [];




// ===== UTILS =====
// LƯU Ý: file này chỉ được có 1 normalizePhone. Nếu build báo trùng => bạn đang có 2 cái, xoá bớt 1.
function normalizePhone(s) {
    let x = (s || "").replace(/\s+/g, "");
    x = x.replace(/^\+?84/, "0");
    return x;
}

function formatPrice(price) {
    return new Intl.NumberFormat("vi-VN").format(Number(price || 0)) + "đ";
}

function minutesToText(m) {
    const mm = Number(m || 0);
    if (mm < 60) return `${mm} phút`;
    const h = Math.floor(mm / 60);
    const r = mm % 60;
    return r ? `${h} giờ ${r} phút` : `${h} giờ`;
}


function computeEndTime(dateStr, timeStr, totalMin) {
    if (!dateStr || !timeStr || !totalMin) return "-";
    const d = new Date(`${dateStr}T${timeStr}:00`);
    d.setMinutes(d.getMinutes() + Number(totalMin));
    const hh = String(d.getHours()).padStart(2, "0");
    const mm = String(d.getMinutes()).padStart(2, "0");
    return `${hh}:${mm}`;
}



function showToast(message, type = "success") {
    const container = $("toast-container");
    if (!container) return;

    const toast = document.createElement("div");
    const base = "px-6 py-3 rounded-xl shadow-lg slide-in";
    const cls =
        type === "success" ? "bg-green-500 text-white" :
            type === "error" ? "bg-red-500 text-white" :
                "bg-gray-200 text-black";

    toast.className = `${base} ${cls}`;
    toast.innerHTML = `<p class="font-medium">${message}</p>`;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

function showLoading(show) {
    const el = $("loading-overlay");
    if (!el) return;

    el.classList.toggle("hidden", !show);
    el.classList.toggle("flex", show);
}

async function fetchJson(url, opts = {}) {
    const res = await fetch(url, {
        headers: { Accept: "application/json", ...(opts.headers || {}) },
        ...opts,
    });
    const json = await res.json().catch(() => ({}));
    return { res, json };
}



// ===== MOBILE MENU =====
window.toggleMobileMenu = function () {
    const menu = $("mobile-menu");
    const overlay = $("mobile-overlay");

    menu?.classList.toggle("-translate-x-full");

    overlay?.classList.toggle("hidden");
};








window.resetBooking = function () {
    currentStep = 1;
    bookingData = { services: [], stylist: null, date: null, time: null };
    availableTimes = new Set();

    document.querySelectorAll(".booking-step").forEach((s) => s.classList.add("hidden"));
    $("booking-step-1")?.classList.remove("hidden");
    $("booking-success")?.classList.add("hidden");

    ["customer-name", "customer-phone", "customer-email", "customer-notes"].forEach((id) => {
        if ($(id)) $(id).value = "";
    });

    updateStepIndicators();
    renderServices();
    renderStylists();
    renderTimeSlots();
    updateSummary();
};
// =========================================================
// SUBMIT BOOKING
// =========================================================
window.submitBooking = async function () {
    console.log("=== SUBMIT BOOKING START ===");

    // Lấy dữ liệu từ form
    const name = $("customer-name").value.trim();
    const phone = normalizePhone($("customer-phone").value.trim());
    const email = $("customer-email").value.trim();
    const notes = $("customer-notes").value.trim();

    console.log("Form data:", { name, phone, email, notes });

    // Validate phía client
    if (!name || !phone || !email) {
        console.warn("❌ Thiếu thông tin khách");
        showToast("Vui lòng nhập họ tên, số điện thoại và email", "error");
        return;
    }

    // Kiểm tra bookingData
    console.log("Booking data:", bookingData);

    if (!bookingData.services?.length || !bookingData.stylist || !bookingData.date || !bookingData.time) {
        console.warn("❌ Thiếu thông tin booking");
        showToast("Thiếu thông tin đặt lịch", "error");
        return;
    }

    showLoading(true);

    try {
        console.log("🚀 Gửi request đến:", window.Barbery.routes.createBooking);

        const res = await fetch(window.Barbery.routes.createBooking, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Accept: "application/json",
                "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]')?.content || "",
                "X-Requested-With": "XMLHttpRequest",
            },
            body: JSON.stringify({
                customer_name: name,
                customer_phone: phone,
                customer_email: email,
                service_ids: bookingData.services.map((s) => s.id),
                stylist_id: bookingData.stylist.id,
                booking_date: bookingData.date,
                booking_time: bookingData.time,
                notes: notes || null,
            }),
        });

        console.log("📥 Response status:", res.status);

        // đọc text trước để debug
        const text = await res.text();
        console.log("📦 Raw response:", text);

        let json = {};
        try {
            json = JSON.parse(text);
        } catch (e) {
            console.error("❌ Không parse được JSON:", e);
        }

        showLoading(false);

        if (!res.ok) {
            console.error("❌ Server trả lỗi:", json);
            showToast(json.message || "Lỗi đặt lịch", "error");
            return;
        }

        console.log("✅ Booking success:", json);

        document.querySelectorAll(".booking-step").forEach((s) => s.classList.add("hidden"));
        $("booking-success")?.classList.remove("hidden");

        const codeEl = $("booking-code-display");
        if (codeEl) {
            codeEl.textContent = json.data?.booking_code || "N/A";
        }

        showToast("Đặt lịch thành công!");
    } catch (error) {
        showLoading(false);

        console.error("🔥 FETCH ERROR:", error);

        if (error instanceof TypeError) {
            console.error("👉 Có thể do sai URL hoặc server chưa chạy");
        }

        showToast("Có lỗi xảy ra, vui lòng thử lại", "error");
    }

    console.log("=== SUBMIT BOOKING END ===");
};

// =========================================================
// LOOKUP
// =========================================================
async function handleLookupSubmit(e) {
    e.preventDefault();

    const input = $("lookup-input");
    const q = normalizePhone(input?.value?.trim());
    if (!q) return;

    showLoading(true);
    try {
        const { res, json } = await fetchJson(`${window.Barbery.routes.lookup}?q=${encodeURIComponent(q)}`);
        showLoading(false);

        if (!res.ok || !json?.ok) {
            showToast(json?.message || "Tra cứu lỗi", "error");
            return;
        }

        const resultsWrap = $("lookup-results");
        const emptyWrap = $("lookup-empty");
        const list = $("lookup-list");

        if (list) list.innerHTML = "";

        const items = json.data || [];
        if (items.length === 0) {
            resultsWrap?.classList.add("hidden");
            emptyWrap?.classList.remove("hidden");
            return;
        }

        emptyWrap?.classList.add("hidden");
        resultsWrap?.classList.remove("hidden");

        if (list) {
            list.innerHTML = items.map((b) => {
                const durationText = b.total_duration_min ? minutesToText(b.total_duration_min) : "-";
                const endTime = b.total_duration_min
                    ? computeEndTime(b.booking_date, b.booking_time, b.total_duration_min)
                    : "-";

                return `
          <div class="bg-dark p-4 rounded-xl border border-gray-800">
            <p class="font-semibold text-gold">Mã: ${b.booking_code}</p>
            <p>Dịch vụ: ${b.service_name}</p>
            <p>Thợ: ${b.stylist_name}</p>

            <p>Ngày: ${b.booking_date}</p>
            <p>Giờ bắt đầu: ${b.booking_time}</p>
            <p>Tổng thời gian: ${durationText}</p>
            <p>Giờ kết thúc: ${endTime}</p>

            <p class="text-sm text-gray-400">Trạng thái: ${b.status}</p>
          </div>
        `;
            }).join("");
        }
    } catch {
        showLoading(false);
        showToast("Không kết nối server", "error");
    }
}

// =========================================================
// INIT
// =========================================================
document.addEventListener("DOMContentLoaded", async () => {
    try {
        // Booking page
        if ($("service-list")) {
            showLoading(true);
            await loadCatalog();
            renderServices();
            renderStylists();
            updateStepIndicators();
            renderTimeSlots();
            updateSummary();
            showLoading(false);
        }

        // Lookup page
        const form = $("lookup-form");
        if (form) form.addEventListener("submit", handleLookupSubmit);
    } catch (e) {
        console.error(e);
        showLoading(false);
        showToast(e?.message || "Lỗi tải dữ liệu", "error");
    }
    // ===== NAV ACTIVE ON SCROLL =====
    const navLinks = document.querySelectorAll(".nav-link[data-section]");
    const scrollBox = document.getElementById("app") || window;

    function setActiveNav() {
        if (!navLinks.length) return;

        let current = "home";

        navLinks.forEach(link => {
            const section = document.getElementById(link.dataset.section);
            if (!section) return;

            const top = section.getBoundingClientRect().top;

            if (top <= 160) {
                current = link.dataset.section;
            }
        });

        navLinks.forEach(link => {
            const isActive = link.dataset.section === current;

            link.classList.toggle("text-gold", isActive);
            link.classList.toggle("font-bold", isActive);
            link.classList.toggle("text-gray-300", !isActive);
        });
    }

    scrollBox.addEventListener("scroll", setActiveNav);
    window.addEventListener("load", setActiveNav);
    window.addEventListener("hashchange", () => {
        setTimeout(setActiveNav, 200);
    });

    setTimeout(setActiveNav, 300);
});
